import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/audio_provider.dart';
import '../../data/demo_songs.dart';
import '../../models/song.dart';
import '../../utils/constaints.dart';
import '../../utils/constants.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Song> _searchResults = [];

  void _performSearch(String query) {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }

    setState(() {
      _searchResults = demoSongs
          .where((song) =>
      song.title.toLowerCase().contains(query.toLowerCase()) ||
          song.artist.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isSmallScreen = size.width < 400;

    return Consumer<AudioProvider>(
      builder: (context, audioProvider, child) {
        return Scaffold(
          appBar: AppBar(
            title: Container(
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppConstants.largeBorderRadius),
              ),
              child: TextField(
                controller: _searchController,
                style: AppTextStyles.bodyMedium,
                decoration: InputDecoration(
                  hintText: 'Search songs or artists...',
                  hintStyle: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.textSecondary,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: AppConstants.defaultPadding,
                    vertical: AppConstants.smallPadding,
                  ),
                  prefixIcon: Icon(
                    Icons.search,
                    color: AppColors.textSecondary,
                  ),
                  suffixIcon: _searchController.text.isNotEmpty
                      ? IconButton(
                    icon: Icon(
                      Icons.clear,
                      color: AppColors.textSecondary,
                    ),
                    onPressed: () {
                      _searchController.clear();
                      _performSearch('');
                    },
                  )
                      : null,
                ),
                onChanged: _performSearch,
              ),
            ),
          ),
          body: _searchResults.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.search,
                  size: isSmallScreen ? 80 : 100,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Text(
                    _searchController.text.isEmpty
                        ? 'Search for your favorite songs'
                        : 'No results found',
                    style: AppTextStyles.bodyLarge.copyWith(
                      color: AppColors.textSecondary,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          )
              : ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: AppConstants.smallPadding),
            itemCount: _searchResults.length,
            itemBuilder: (context, index) {
              final song = _searchResults[index];
              final isCurrentSong = audioProvider.currentSong?.id == song.id;

              return Container(
                height: isSmallScreen ? 70 : 80,
                margin: const EdgeInsets.symmetric(
                  horizontal: AppConstants.defaultPadding,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: isCurrentSong
                      ? AppColors.primary.withOpacity(0.1)
                      : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                ),
                child: Row(
                  children: [
                    // Song Image
                    Padding(
                      padding: const EdgeInsets.all(AppConstants.smallPadding),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(AppConstants.smallBorderRadius),
                        child: Image.network(
                          song.coverUrl,
                          width: isSmallScreen ? 50 : 60,
                          height: isSmallScreen ? 50 : 60,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.grey[800],
                              child: Icon(
                                Icons.music_note,
                                size: isSmallScreen ? 25 : 30,
                                color: Colors.white,
                              ),
                            );
                          },
                        ),
                      ),
                    ),

                    // Song Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            song.title,
                            style: AppTextStyles.songTitle.copyWith(
                              fontSize: isSmallScreen ? 14 : 16,
                              color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            song.artist,
                            style: AppTextStyles.songArtist.copyWith(
                              fontSize: isSmallScreen ? 12 : 14,
                              color: isCurrentSong
                                  ? AppColors.primary.withOpacity(0.7)
                                  : AppColors.textSecondary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),

                    // Control Buttons
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(
                            audioProvider.favorites.contains(song.id)
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: AppColors.favoriteActive,
                            size: 20,
                          ),
                          onPressed: () => audioProvider.toggleFavorite(song.id),
                        ),
                        IconButton(
                          icon: Icon(
                            isCurrentSong && audioProvider.isPlaying
                                ? Icons.pause_circle
                                : Icons.play_circle,
                            size: isSmallScreen ? 28 : 32,
                            color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                          ),
                          onPressed: () => audioProvider.playSong(song),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}