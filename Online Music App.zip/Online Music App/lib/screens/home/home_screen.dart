import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/audio_provider.dart';
import '../../data/demo_songs.dart';
import '../../utils/constaints.dart';
import '../../utils/constants.dart';
import '../player/full_player_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isSmallScreen = size.width < 400;

    return Consumer<AudioProvider>(
      builder: (context, audioProvider, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              AppConstants.appName,
              style: AppTextStyles.h4,
            ),
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          body: SafeArea(
            child: Column(
              children: [
                // Now Playing Card (if song is playing)
                if (audioProvider.currentSong != null) ...[
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const FullPlayerScreen(),
                        ),
                      );
                    },
                    child: Container(
                      margin: const EdgeInsets.all(AppConstants.defaultPadding),
                      padding: const EdgeInsets.all(AppConstants.defaultPadding),
                      decoration: BoxDecoration(
                        gradient: AppColors.cardGradient,
                        borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                      ),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                            child: Image.network(
                              audioProvider.currentSong!.coverUrl,
                              width: 60,
                              height: 60,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  width: 60,
                                  height: 60,
                                  color: Colors.grey[800],
                                  child: const Icon(Icons.music_note),
                                );
                              },
                            ),
                          ),
                          const SizedBox(width: AppConstants.defaultPadding),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Now Playing',
                                  style: AppTextStyles.caption.copyWith(
                                    color: Colors.white.withOpacity(0.8),
                                  ),
                                ),
                                Text(
                                  audioProvider.currentSong!.title,
                                  style: AppTextStyles.songTitle,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  audioProvider.currentSong!.artist,
                                  style: AppTextStyles.songArtist,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          Icon(
                            audioProvider.isPlaying ? Icons.pause : Icons.play_arrow,
                            size: 30,
                            color: AppColors.textPrimary,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],

                // Songs List Header
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppConstants.defaultPadding),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Popular Songs',
                        style: AppTextStyles.h5,
                      ),
                      TextButton(
                        onPressed: () {
                          // TODO: Navigate to all songs
                        },
                        child: Text(
                          'See All',
                          style: TextStyle(color: AppColors.primary),
                        ),
                      ),
                    ],
                  ),
                ),

                // Songs List
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: AppConstants.defaultPadding),
                    itemCount: demoSongs.length,
                    itemBuilder: (context, index) {
                      final song = demoSongs[index];
                      final isCurrentSong = audioProvider.currentSong?.id == song.id;

                      return Container(
                        margin: const EdgeInsets.only(bottom: AppConstants.smallPadding),
                        decoration: BoxDecoration(
                          color: isCurrentSong
                              ? AppColors.primary.withOpacity(0.1)
                              : Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                        ),
                        child: ListTile(
                          leading: ClipRRect(
                            borderRadius: BorderRadius.circular(AppConstants.smallBorderRadius),
                            child: Image.network(
                              song.coverUrl,
                              width: AppConstants.albumArtSizeSmall,
                              height: AppConstants.albumArtSizeSmall,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  width: AppConstants.albumArtSizeSmall,
                                  height: AppConstants.albumArtSizeSmall,
                                  color: Colors.grey[800],
                                  child: const Icon(Icons.music_note),
                                );
                              },
                            ),
                          ),
                          title: Text(
                            song.title,
                            style: AppTextStyles.songTitle.copyWith(
                              fontWeight: isCurrentSong ? FontWeight.bold : FontWeight.normal,
                              color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            song.artist,
                            style: AppTextStyles.songArtist.copyWith(
                              color: isCurrentSong
                                  ? AppColors.primary.withOpacity(0.7)
                                  : AppColors.textSecondary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(
                                  audioProvider.favorites.contains(song.id)
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: AppColors.favoriteActive,
                                  size: 20,
                                ),
                                onPressed: () => audioProvider.toggleFavorite(song.id),
                              ),
                              IconButton(
                                icon: Icon(
                                  isCurrentSong && audioProvider.isPlaying
                                      ? Icons.pause_circle
                                      : Icons.play_circle,
                                  size: 28,
                                  color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                                ),
                                onPressed: () => audioProvider.playSong(song),
                              ),
                            ],
                          ),
                          onTap: () => audioProvider.playSong(song),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}