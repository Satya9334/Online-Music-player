import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import '../../providers/audio_provider.dart';
import '../../models/song.dart';  // ✅ Import AppLoopMode from here
import '../../utils/constaints.dart';
import '../../utils/constants.dart';

class FullPlayerScreen extends StatelessWidget {
  const FullPlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AudioProvider>(
      builder: (context, audioProvider, child) {
        final currentSong = audioProvider.currentSong;
        final size = MediaQuery.of(context).size;
        final isSmallScreen = size.width < 400;

        if (currentSong == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Player')),
            body: Center(
              child: Text(
                'No song selected',
                style: AppTextStyles.bodyLarge,
              ),
            ),
          );
        }

        return Scaffold(
          backgroundColor: AppColors.backgroundDark,
          appBar: AppBar(
            title: Text(
              'Now Playing',
              style: AppTextStyles.h5,
            ),
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppConstants.largePadding),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(),

                  // Album Art
                  Container(
                    width: isSmallScreen ? 280 : 320,
                    height: isSmallScreen ? 280 : 320,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(AppConstants.largeBorderRadius),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.3),
                          blurRadius: 15,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(AppConstants.largeBorderRadius),
                      child: Image.network(
                        currentSong.coverUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[800],
                            child: const Icon(
                              Icons.music_note,
                              size: 100,
                              color: Colors.white,
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Song Info
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentSong.title,
                              style: AppTextStyles.playerTitle.copyWith(
                                fontSize: isSmallScreen ? 22 : 26,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              currentSong.artist,
                              style: AppTextStyles.playerArtist.copyWith(
                                fontSize: isSmallScreen ? 16 : 18,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          audioProvider.favorites.contains(currentSong.id)
                              ? Icons.favorite
                              : Icons.favorite_border,
                          color: AppColors.favoriteActive,
                          size: isSmallScreen ? 28 : 32,
                        ),
                        onPressed: () => audioProvider.toggleFavorite(currentSong.id),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  // Progress Bar
                  ProgressBar(
                    progress: audioProvider.currentPosition,
                    total: audioProvider.totalDuration,
                    onSeek: audioProvider.seek,
                    baseBarColor: AppColors.progressBarInactive,
                    progressBarColor: AppColors.progressBarActive,
                    thumbColor: AppColors.progressBarActive,
                    barHeight: isSmallScreen ? 4 : 5,
                    thumbRadius: isSmallScreen ? 8 : 10,
                    timeLabelTextStyle: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: isSmallScreen ? 14 : 16,
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Controls Row 1 (Shuffle, Loop)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        iconSize: isSmallScreen ? 25 : 30,
                        icon: Icon(
                          Icons.shuffle,
                          color: audioProvider.isShuffled
                              ? AppColors.primary
                              : AppColors.textSecondary,
                        ),
                        onPressed: audioProvider.toggleShuffle,
                      ),
                      IconButton(
                        iconSize: isSmallScreen ? 25 : 30,
                        icon: Icon(
                          _getLoopIcon(audioProvider.loopMode),
                          color: audioProvider.loopMode != AppLoopMode.none  // ✅ Use imported AppLoopMode
                              ? AppColors.primary
                              : AppColors.textSecondary,
                        ),
                        onPressed: audioProvider.toggleLoopMode,
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Main Controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: isSmallScreen ? 40 : 50,
                        icon: const Icon(Icons.skip_previous),
                        onPressed: audioProvider.playPrevious,
                        color: AppColors.textPrimary,
                      ),
                      const SizedBox(width: 20),
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          iconSize: isSmallScreen ? 50 : 60,
                          icon: Icon(
                            audioProvider.isPlaying ? Icons.pause : Icons.play_arrow,
                            color: Colors.white,
                          ),
                          onPressed: audioProvider.playPause,
                        ),
                      ),
                      const SizedBox(width: 20),
                      IconButton(
                        iconSize: isSmallScreen ? 40 : 50,
                        icon: const Icon(Icons.skip_next),
                        onPressed: audioProvider.playNext,
                        color: AppColors.textPrimary,
                      ),
                    ],
                  ),

                  const Spacer(),

                  // Loop Mode Text
                  Text(
                    _getLoopModeText(audioProvider.loopMode),
                    style: AppTextStyles.caption,
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ✅ Use imported AppLoopMode from models/song.dart
  IconData _getLoopIcon(AppLoopMode loopMode) {
    switch (loopMode) {
      case AppLoopMode.none:
        return Icons.repeat;
      case AppLoopMode.single:
        return Icons.repeat_one;
      case AppLoopMode.playlist:
        return Icons.repeat;
    }
  }

  // ✅ Use imported AppLoopMode from models/song.dart
  String _getLoopModeText(AppLoopMode loopMode) {
    switch (loopMode) {
      case AppLoopMode.none:
        return 'No Repeat';
      case AppLoopMode.single:
        return 'Repeat Song';
      case AppLoopMode.playlist:
        return 'Repeat Playlist';
    }
  }
}