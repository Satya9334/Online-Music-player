import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/audio_provider.dart';
import '../../data/demo_songs.dart';
import '../../utils/constaints.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

@override
Widget build(BuildContext context) {
  final size = MediaQuery.of(context).size;
  final isSmallScreen = size.width < 400;

  return Consumer<AudioProvider>(
    builder: (context, audioProvider, child) {
      final favoriteSongs = demoSongs
          .where((song) => audioProvider.favorites.contains(song.id))
          .toList();

      return Scaffold(
        appBar: AppBar(
          title: Text(
            'Favorites',
            style: AppTextStyles.h4,
          ),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: favoriteSongs.isEmpty
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.favorite_border,
                size: isSmallScreen ? 80 : 100,
                color: AppColors.textSecondary,
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                  'No favorite songs yet',
                  style: AppTextStyles.bodyLarge.copyWith(
                    color: AppColors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Start adding songs to your favorites!',
                style: AppTextStyles.bodyMedium.copyWith(
                  color: AppColors.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        )
            : Column(
          children: [
            // Stats
            Container(
              margin: const EdgeInsets.all(AppConstants.defaultPadding),
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.favorite,
                    color: AppColors.favoriteActive,
                    size: 24,
                  ),
                  const SizedBox(width: AppConstants.smallPadding),
                  Text(
                    '${favoriteSongs.length} Favorite Songs',
                    style: AppTextStyles.h6,
                  ),
                ],
              ),
            ),

            // Songs List
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: AppConstants.defaultPadding),
                itemCount: favoriteSongs.length,
                itemBuilder: (context, index) {
                  final song = favoriteSongs[index];
                  final isCurrentSong = audioProvider.currentSong?.id == song.id;

                  return Dismissible(
                    key: Key(song.id),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      margin: const EdgeInsets.only(bottom: AppConstants.smallPadding),
                      decoration: BoxDecoration(
                        color: AppColors.error.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                      ),
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: AppConstants.largePadding),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.delete,
                            color: Colors.white,
                            size: 24,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Remove',
                            style: AppTextStyles.caption.copyWith(
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                    onDismissed: (_) {
                      audioProvider.toggleFavorite(song.id);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(AppConstants.successSongRemoved),
                          backgroundColor: AppColors.success,
                          duration: AppDurations.snackBarDuration,
                        ),
                      );
                    },
                    child: GestureDetector(
                      onTap: () => audioProvider.playSong(song),
                      child: Container(
                        height: isSmallScreen ? 70 : 80,
                        margin: const EdgeInsets.only(bottom: AppConstants.smallPadding),
                        decoration: BoxDecoration(
                          color: isCurrentSong
                              ? AppColors.primary.withOpacity(0.1)
                              : Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(AppConstants.defaultBorderRadius),
                        ),
                        child: Row(
                          children: [
                            // Song Image
                            Padding(
                              padding: const EdgeInsets.all(AppConstants.smallPadding),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(AppConstants.smallBorderRadius),
                                child: Image.network(
                                  song.coverUrl,
                                  width: isSmallScreen ? 50 : 60,
                                  height: isSmallScreen ? 50 : 60,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: Colors.grey[800],
                                      child: Icon(
                                        Icons.music_note,
                                        size: isSmallScreen ? 25 : 30,
                                        color: Colors.white,
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),

                            // Song Info
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    song.title,
                                    style: AppTextStyles.songTitle.copyWith(
                                      fontSize: isSmallScreen ? 14 : 16,
                                      color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    song.artist,
                                    style: AppTextStyles.songArtist.copyWith(
                                      fontSize: isSmallScreen ? 12 : 14,
                                      color: isCurrentSong
                                          ? AppColors.primary.withOpacity(0.7)
                                          : AppColors.textSecondary,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),

                            // Play Button
                            Padding(
                              padding: const EdgeInsets.only(right: AppConstants.smallPadding),
                              child: IconButton(
                                icon: Icon(
                                  isCurrentSong && audioProvider.isPlaying
                                      ? Icons.pause_circle_filled
                                      : Icons.play_circle,
                                  size: isSmallScreen ? 35 : 40,
                                  color: isCurrentSong ? AppColors.primary : AppColors.textPrimary,
                                ),
                                onPressed: () => audioProvider.playSong(song),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      );
    },
  );
}
}