import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import '../providers/audio_provider.dart';
import '../screens/player/full_player_screen.dart';
import '../utils/constaints.dart';
import '../utils/constants.dart';

class BottomPlayer extends StatelessWidget {
  const BottomPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AudioProvider>(
      builder: (context, audioProvider, child) {
        final currentSong = audioProvider.currentSong;

        if (currentSong == null) return const SizedBox.shrink();

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const FullPlayerScreen(),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.surfaceDark,
              border: Border(
                top: BorderSide(
                  color: Colors.white.withOpacity(0.1),
                  width: 0.5,
                ),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Progress Bar
                ProgressBar(
                  progress: audioProvider.currentPosition,
                  total: audioProvider.totalDuration,
                  onSeek: audioProvider.seek,
                  baseBarColor: AppColors.progressBarInactive,
                  progressBarColor: AppColors.progressBarActive,
                  thumbColor: AppColors.progressBarActive,
                  barHeight: 2,
                  thumbRadius: 0,
                  timeLabelLocation: TimeLabelLocation.none,
                ),

                // Player Controls
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppConstants.defaultPadding,
                      vertical: AppConstants.smallPadding
                  ),
                  child: Row(
                    children: [
                      // Song Image
                      ClipRRect(
                        borderRadius: BorderRadius.circular(AppConstants.smallBorderRadius),
                        child: Image.network(
                          currentSong.coverUrl,
                          width: AppConstants.albumArtSizeSmall,
                          height: AppConstants.albumArtSizeSmall,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: AppConstants.albumArtSizeSmall,
                              height: AppConstants.albumArtSizeSmall,
                              color: Colors.grey[800],
                              child: const Icon(
                                Icons.music_note,
                                color: Colors.white,
                                size: 25,
                              ),
                            );
                          },
                        ),
                      ),

                      const SizedBox(width: 12),

                      // Song Info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentSong.title,
                              style: AppTextStyles.songTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              currentSong.artist,
                              style: AppTextStyles.songArtist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),

                      // Controls
                      IconButton(
                        icon: const Icon(Icons.skip_previous, size: 24),
                        onPressed: audioProvider.playPrevious,
                        color: AppColors.textPrimary,
                      ),
                      IconButton(
                        icon: Icon(
                          audioProvider.isPlaying
                              ? Icons.pause_circle_filled
                              : Icons.play_circle_filled,
                          size: 40,
                        ),
                        onPressed: audioProvider.playPause,
                        color: AppColors.primary,
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_next, size: 24),
                        onPressed: audioProvider.playNext,
                        color: AppColors.textPrimary,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}