import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/song.dart';
import '../data/demo_songs.dart';

class AudioProvider extends ChangeNotifier {
  final AudioPlayer _audioPlayer = AudioPlayer();

  // Current state
  List<Song> _playlist = demoSongs;
  List<Song> _originalPlaylist = List.from(demoSongs);  // ✅ Added: Keep original order
  int _currentIndex = 0;
  bool _isPlaying = false;
  AppLoopMode _loopMode = AppLoopMode.none;
  Set<String> _favorites = {};
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  bool _isShuffled = false;

  // Getters
  AudioPlayer get audioPlayer => _audioPlayer;
  List<Song> get playlist => _playlist;
  int get currentIndex => _currentIndex;
  Song? get currentSong => _playlist.isNotEmpty ? _playlist[_currentIndex] : null;
  bool get isPlaying => _isPlaying;
  AppLoopMode get loopMode => _loopMode;
  Set<String> get favorites => _favorites;
  Duration get currentPosition => _currentPosition;
  Duration get totalDuration => _totalDuration;
  bool get isShuffled => _isShuffled;

  AudioProvider() {
    _initializePlayer();
    _loadFavorites();
  }

  void _initializePlayer() {
    // Listen to player state changes
    _audioPlayer.playerStateStream.listen((state) {
      _isPlaying = state.playing;
      notifyListeners();
    });

    // Listen to position changes
    _audioPlayer.positionStream.listen((position) {
      _currentPosition = position;
      notifyListeners();
    });

    // Listen to duration changes
    _audioPlayer.durationStream.listen((duration) {
      _totalDuration = duration ?? Duration.zero;
      notifyListeners();
    });

    // Listen to player completion
    _audioPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _handleSongCompletion();
      }
    });
  }

  void _handleSongCompletion() {
    switch (_loopMode) {
      case AppLoopMode.single:
      // Replay the same song
        _audioPlayer.seek(Duration.zero);
        _audioPlayer.play();
        break;
      case AppLoopMode.playlist:
      // Go to next song, or first song if at end
        if (_currentIndex < _playlist.length - 1) {
          playNext();
        } else {
          playByIndex(0);
        }
        break;
      case AppLoopMode.none:
      // Go to next song if available
        if (_currentIndex < _playlist.length - 1) {
          playNext();
        } else {
          // Stop at the end
          _isPlaying = false;
          notifyListeners();
        }
        break;
    }
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    _favorites = (prefs.getStringList('favorites') ?? []).toSet();
    notifyListeners();
  }

  Future<void> toggleFavorite(String songId) async {
    final prefs = await SharedPreferences.getInstance();
    if (_favorites.contains(songId)) {
      _favorites.remove(songId);
    } else {
      _favorites.add(songId);
    }
    await prefs.setStringList('favorites', _favorites.toList());
    notifyListeners();
  }

  Future<void> playByIndex(int index) async {
    if (index < 0 || index >= _playlist.length) return;

    _currentIndex = index;
    await _audioPlayer.stop();

    try {
      await _audioPlayer.setUrl(_playlist[index].audioUrl);
      await _audioPlayer.play();
    } catch (e) {
      debugPrint('Error playing song: $e');
    }

    notifyListeners();
  }

  Future<void> playSong(Song song) async {
    final index = _playlist.indexWhere((s) => s.id == song.id);
    if (index != -1) {
      await playByIndex(index);
    }
  }

  Future<void> playPause() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.play();
    }
  }

  Future<void> playNext() async {
    if (_currentIndex < _playlist.length - 1) {
      await playByIndex(_currentIndex + 1);
    } else if (_loopMode == AppLoopMode.playlist) {
      await playByIndex(0);
    }
  }

  Future<void> playPrevious() async {
    if (_currentIndex > 0) {
      await playByIndex(_currentIndex - 1);
    } else if (_loopMode == AppLoopMode.playlist) {
      await playByIndex(_playlist.length - 1);
    }
  }

  void toggleLoopMode() {
    switch (_loopMode) {
      case AppLoopMode.none:
        _loopMode = AppLoopMode.single;
        break;
      case AppLoopMode.single:
        _loopMode = AppLoopMode.playlist;
        break;
      case AppLoopMode.playlist:
        _loopMode = AppLoopMode.none;
        break;
    }
    notifyListeners();
  }

  // ✅ Fixed: Better shuffle functionality
  void toggleShuffle() {
    final currentSong = _playlist.isNotEmpty ? _playlist[_currentIndex] : null;

    _isShuffled = !_isShuffled;

    if (_isShuffled) {
      // ✅ Turn off loop mode when shuffling
      _loopMode = AppLoopMode.none;

      // ✅ Create shuffled playlist
      List<Song> shuffledList = List.from(_originalPlaylist);

      // Remove current song from list to shuffle
      if (currentSong != null) {
        shuffledList.removeWhere((song) => song.id == currentSong.id);
      }

      // Shuffle the remaining songs
      shuffledList.shuffle();

      // Put current song at the beginning
      if (currentSong != null) {
        shuffledList.insert(0, currentSong);
      }

      _playlist = shuffledList;
      _currentIndex = 0; // Current song is now at index 0

    } else {
      // ✅ Return to original playlist order
      _playlist = List.from(_originalPlaylist);

      // ✅ Find current song index in original playlist
      if (currentSong != null) {
        _currentIndex = _playlist.indexWhere((song) => song.id == currentSong.id);
        if (_currentIndex == -1) _currentIndex = 0;
      } else {
        _currentIndex = 0;
      }
    }

    notifyListeners();
  }

  // ✅ Added: Shuffle and play next song immediately
  Future<void> shuffleAndPlayNext() async {
    if (!_isShuffled) {
      toggleShuffle(); // Turn on shuffle first
    }

    // Get next random song (excluding current)
    final currentSong = _playlist[_currentIndex];
    List<Song> availableSongs = _playlist
        .where((song) => song.id != currentSong.id)
        .toList();

    if (availableSongs.isNotEmpty) {
      availableSongs.shuffle();
      final nextSong = availableSongs.first;
      await playSong(nextSong);
    }
  }

  Future<void> seek(Duration position) async {
    await _audioPlayer.seek(position);
  }

  void setPlaylist(List<Song> songs, {int startIndex = 0}) {
    _playlist = songs;
    _originalPlaylist = List.from(songs);  // ✅ Update original playlist too
    _currentIndex = startIndex;
    _isShuffled = false;  // Reset shuffle when setting new playlist
    notifyListeners();
  }

  // ✅ Added: Get next song preview (for UI)
  Song? getNextSong() {
    if (_playlist.isEmpty) return null;

    int nextIndex;
    if (_currentIndex < _playlist.length - 1) {
      nextIndex = _currentIndex + 1;
    } else {
      nextIndex = _loopMode == AppLoopMode.playlist ? 0 : _currentIndex;
    }

    return nextIndex < _playlist.length ? _playlist[nextIndex] : null;
  }

  // ✅ Added: Get previous song preview (for UI)
  Song? getPreviousSong() {
    if (_playlist.isEmpty) return null;

    int prevIndex;
    if (_currentIndex > 0) {
      prevIndex = _currentIndex - 1;
    } else {
      prevIndex = _loopMode == AppLoopMode.playlist ? _playlist.length - 1 : _currentIndex;
    }

    return prevIndex >= 0 ? _playlist[prevIndex] : null;
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}