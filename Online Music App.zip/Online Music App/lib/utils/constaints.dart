import 'package:flutter/material.dart';

class AppConstants {
  // App Information
  static const String appName = 'Music App';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'A beautiful music streaming app built with Flutter';

  // Developer Information
  static const String developerName = 'Music App Team';
  static const String developerEmail = 'support@musicapp.com';
  static const String supportUrl = 'https://musicapp.com/support';
  static const String privacyPolicyUrl = 'https://musicapp.com/privacy';
  static const String termsOfServiceUrl = 'https://musicapp.com/terms';

  // SharedPreferences Keys
  static const String keyFavorites = 'user_favorites';
  static const String keyThemeMode = 'theme_mode';
  static const String keyAudioQuality = 'audio_quality';
  static const String keyAutoPlay = 'auto_play';
  static const String keyNotifications = 'notifications_enabled';
  static const String keyDownloadQuality = 'download_quality';
  static const String keyOnboardingCompleted = 'onboarding_completed';
  static const String keyLastPlayedSong = 'last_played_song';
  static const String keyPlaybackPosition = 'playback_position';
  static const String keyRepeatMode = 'repeat_mode';
  static const String keyShuffleMode = 'shuffle_mode';

  // Audio Quality
  static const String audioQualityLow = 'low';
  static const String audioQualityMedium = 'medium';
  static const String audioQualityHigh = 'high';
  static const String audioQualityLossless = 'lossless';

  // Animation Durations
  static const Duration animationDurationShort = Duration(milliseconds: 200);
  static const Duration animationDurationMedium = Duration(milliseconds: 400);
  static const Duration animationDurationLong = Duration(milliseconds: 600);

  // Network Timeouts
  static const Duration networkTimeout = Duration(seconds: 30);
  static const Duration streamTimeout = Duration(seconds: 10);

  // Player Settings
  static const Duration seekDuration = Duration(seconds: 10);
  static const double defaultVolume = 0.8;
  static const int maxRecentSongs = 50;
  static const int maxSearchHistory = 20;

  // Image URLs (Placeholders)
  static const String defaultAvatarUrl = 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';
  static const String defaultAlbumCoverUrl = 'https://via.placeholder.com/500x500/333333/FFFFFF?text=Music';

  // Error Messages
  static const String errorNetworkConnection = 'Please check your internet connection';
  static const String errorPlaybackFailed = 'Failed to play the song';
  static const String errorSongNotFound = 'Song not found';
  static const String errorGeneral = 'Something went wrong. Please try again';
  static const String errorAuthFailed = 'Authentication failed';
  static const String errorUserNotFound = 'User not found';
  static const String errorInvalidCredentials = 'Invalid email or password';

  // Success Messages
  static const String successSongAdded = 'Song added to favorites';
  static const String successSongRemoved = 'Song removed from favorites';
  static const String successAccountCreated = 'Account created successfully';
  static const String successPasswordReset = 'Password reset email sent';
  static const String successProfileUpdated = 'Profile updated successfully';

  // Validation Rules
  static const int minPasswordLength = 6;
  static const int maxPasswordLength = 128;
  static const int minNameLength = 2;
  static const int maxNameLength = 50;

  // UI Measurements
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
  static const double defaultBorderRadius = 12.0;
  static const double smallBorderRadius = 8.0;
  static const double largeBorderRadius = 20.0;
  static const double defaultElevation = 4.0;

  // Player UI
  static const double miniPlayerHeight = 70.0;
  static const double bottomPlayerHeight = 90.0;
  static const double albumArtSizeSmall = 50.0;
  static const double albumArtSizeMedium = 200.0;
  static const double albumArtSizeLarge = 300.0;

  // Grid Dimensions
  static const int gridCrossAxisCountMobile = 2;
  static const int gridCrossAxisCountTablet = 3;
  static const double gridAspectRatio = 0.75;

  // Regular Expressions
  static const String emailRegex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
  static const String phoneRegex = r'^\+?[1-9]\d{1,14}$';
}

class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF2196F3);
  static const Color primaryDark = Color(0xFF1976D2);
  static const Color primaryLight = Color(0xFF64B5F6);

  // Secondary Colors
  static const Color secondary = Color(0xFF9C27B0);
  static const Color secondaryDark = Color(0xFF7B1FA2);
  static const Color secondaryLight = Color(0xFFBA68C8);

  // Background Colors
  static const Color backgroundDark = Color(0xFF121212);
  static const Color backgroundLight = Color(0xFFFAFAFA);
  static const Color surfaceDark = Color(0xFF1E1E1E);
  static const Color surfaceLight = Color(0xFFFFFFFF);

  // Text Colors
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xB3FFFFFF);
  static const Color textDisabled = Color(0x61FFFFFF);
  static const Color textPrimaryLight = Color(0xFF212121);
  static const Color textSecondaryLight = Color(0xFF757575);

  // Status Colors
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  static const Color info = Color(0xFF2196F3);

  // Player Colors
  static const Color playerBackground = Color(0xFF1A1A1A);
  static const Color progressBarActive = Color(0xFF2196F3);
  static const Color progressBarInactive = Color(0xFF424242);
  static const Color favoriteActive = Color(0xFFE91E63);
  static const Color favoriteInactive = Color(0xFF757575);

  // Gradient Colors
  static const Gradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primary, primaryDark],
  );

  static const Gradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [primary, backgroundDark],
  );

  static const Gradient cardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF2196F3),
      Color(0xFF9C27B0),
    ],
  );
}

class AppTextStyles {
  // Headings
  static const TextStyle h1 = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );

  static const TextStyle h2 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );

  static const TextStyle h3 = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static const TextStyle h4 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static const TextStyle h5 = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: AppColors.textPrimary,
  );

  static const TextStyle h6 = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    color: AppColors.textPrimary,
  );

  // Body Text
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.normal,
    color: AppColors.textPrimary,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    color: AppColors.textPrimary,
  );

  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
  );

  // Button Text
  static const TextStyle button = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static const TextStyle buttonSmall = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  // Caption and Labels
  static const TextStyle caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
  );

  static const TextStyle label = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w500,
    color: AppColors.textSecondary,
  );

  // Song-specific styles
  static const TextStyle songTitle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static const TextStyle songArtist = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
  );

  static const TextStyle playerTitle = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );

  static const TextStyle playerArtist = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
  );
}

class AppDurations {
  static const Duration splashScreenDuration = Duration(seconds: 3);
  static const Duration snackBarDuration = Duration(seconds: 4);
  static const Duration toastDuration = Duration(seconds: 2);
  static const Duration searchDebounce = Duration(milliseconds: 500);
  static const Duration autoPlayDelay = Duration(seconds: 1);
  static const Duration fadeInDuration = Duration(milliseconds: 300);
  static const Duration slideInDuration = Duration(milliseconds: 400);
}