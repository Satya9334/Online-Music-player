import 'package:just_audio/just_audio.dart';
import '../models/song.dart';

class AudioService {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;
  AudioService._internal();

  final AudioPlayer _audioPlayer = AudioPlayer();

  AudioPlayer get audioPlayer => _audioPlayer;

  Future<void> initializePlayer() async {
    try {
      // ✅ Fixed: Use just_audio's LoopMode explicitly
      await _audioPlayer.setLoopMode(LoopMode.off);
    } catch (e) {
      print('Error initializing audio player: $e');
    }
  }

  Future<void> playSong(Song song) async {
    try {
      await _audioPlayer.setUrl(song.audioUrl);
      await _audioPlayer.play();
    } catch (e) {
      throw Exception('Error playing song: $e');
    }
  }

  Future<void> pauseSong() async {
    try {
      await _audioPlayer.pause();
    } catch (e) {
      throw Exception('Error pausing song: $e');
    }
  }

  Future<void> resumeSong() async {
    try {
      await _audioPlayer.play();
    } catch (e) {
      throw Exception('Error resuming song: $e');
    }
  }

  Future<void> stopSong() async {
    try {
      await _audioPlayer.stop();
    } catch (e) {
      throw Exception('Error stopping song: $e');
    }
  }

  Future<void> seekTo(Duration position) async {
    try {
      await _audioPlayer.seek(position);
    } catch (e) {
      throw Exception('Error seeking: $e');
    }
  }

  // ✅ Fixed: Set loop mode using just_audio's LoopMode
  Future<void> setLoopMode(LoopMode loopMode) async {
    try {
      await _audioPlayer.setLoopMode(loopMode);
    } catch (e) {
      throw Exception('Error setting loop mode: $e');
    }
  }

  Future<void> setShuffleMode(bool enabled) async {
    try {
      await _audioPlayer.setShuffleModeEnabled(enabled);
    } catch (e) {
      throw Exception('Error setting shuffle mode: $e');
    }
  }

  // Getters
  Stream<Duration> get positionStream => _audioPlayer.positionStream;
  Stream<Duration?> get durationStream => _audioPlayer.durationStream;
  Stream<PlayerState> get playerStateStream => _audioPlayer.playerStateStream;

  Duration get currentPosition => _audioPlayer.position;
  Duration? get duration => _audioPlayer.duration;
  bool get isPlaying => _audioPlayer.playing;

  void dispose() {
    _audioPlayer.dispose();
  }
}