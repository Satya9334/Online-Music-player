import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';
import '../models/song.dart';

class FavoritesService extends ChangeNotifier {
  static const String _favoritesKey = 'user_favorites';

  Set<String> _favoriteIds = {};

  // Getters
  Set<String> get favoriteIds => _favoriteIds;
  int get favoritesCount => _favoriteIds.length;

  // Initialize and load favorites
  Future<void> initialize() async {
    await loadFavorites();
  }

  // Load favorites from SharedPreferences
  Future<void> loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favoriteIdsList = prefs.getStringList(_favoritesKey) ?? [];
      _favoriteIds = favoriteIdsList.toSet();
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading favorites: $e');
    }
  }

  // Save favorites to SharedPreferences
  Future<void> _saveFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_favoritesKey, _favoriteIds.toList());
    } catch (e) {
      debugPrint('Error saving favorites: $e');
    }
  }

  // Add song to favorites
  Future<bool> addToFavorites(String songId) async {
    try {
      if (_favoriteIds.contains(songId)) {
        return false; // Already in favorites
      }

      _favoriteIds.add(songId);
      await _saveFavorites();
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Error adding to favorites: $e');
      return false;
    }
  }

  // Remove song from favorites
  Future<bool> removeFromFavorites(String songId) async {
    try {
      if (!_favoriteIds.contains(songId)) {
        return false; // Not in favorites
      }

      _favoriteIds.remove(songId);
      await _saveFavorites();
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Error removing from favorites: $e');
      return false;
    }
  }

  // Toggle favorite status
  Future<bool> toggleFavorite(String songId) async {
    if (isFavorite(songId)) {
      return await removeFromFavorites(songId);
    } else {
      return await addToFavorites(songId);
    }
  }

  // Check if song is favorite
  bool isFavorite(String songId) {
    return _favoriteIds.contains(songId);
  }

  // Get favorite songs by IDs from a list
  List<Song> getFavoriteSongsFromList(List<Song> allSongs) {
    return allSongs.where((song) => _favoriteIds.contains(song.id)).toList();
  }

  // Clear all favorites
  Future<void> clearAllFavorites() async {
    try {
      _favoriteIds.clear();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_favoritesKey);
      notifyListeners();
    } catch (e) {
      debugPrint('Error clearing favorites: $e');
    }
  }
}