import '../models/song.dart';

final List<Song> demoSongs = [
  Song(
    id: '1',
    title: "Dil Meri Na Sune",
    artist: "Arijit Singh",
    coverUrl: "https://pagalnew.com/coverimages/Dil-Meri-Na-Sune-Reprise-Genius-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/2798",
  ),
  Song(
    id: '2',
    title: "Dheere Dheere",
    artist: "Honey Singh",
    coverUrl: "https://pagalnew.com/coverimages/Dheere-Dheere-Yo-Yo-Honey-Singh-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/24823",
  ),
  Song(
    id: '3',
    title: "Ae Dil Hai Mushkil",
    artist: "Arijit Singh",
    coverUrl: "https://pagalnew.com/coverimages/Ae-Dil-Hai-Mushkil-Title-Track-Pritam-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/4097",
  ),
  Song(
    id: '4',
    title: "Kaun Tujhe",
    artist: "Palak Muchhal",
    coverUrl: "https://pagalnew.com/coverimages/Kaun-Tujhe-M.S.-Dhoni---The-Untold-Story-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/4057",
  ),
  Song(
    id: '5',
    title: "Aaj Zid Remix",
    artist: "Arijit Singh",
    coverUrl: "https://pagalnew.com/coverimages/Aaj-Zid-Remix-By-DJ-Aqeel-Aksar-2-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/3679",
  ),
  Song(
    id: '6',
    title: "Tujh Mein Rab Di",
    artist: "Roopkumar Rathod, Salim-Sulaiman, Jaideep Sahni",
    coverUrl: "https://pagalnew.com/coverimages/Tujh-Mein-Rab-Dikhta-Hai-Rab-Ne-Bana-Di-Jodi-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/8555",
  ),
  Song(
    id: '7',
    title: "Barbaad Saiyaara",
    artist: "Jubin Nautiyal",
    coverUrl: "https://pagalnew.com/coverimages/barbaad-saiyaara-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/51747",
  ),
  Song(
    id: '8',
    title: "Born To Be Gangster",
    artist: "Snehi Pancholi",
    coverUrl: "https://cover.mr-jatt.im/thumb/514590/Born-To-Be-Gangster-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202509/Born_To_Be_Gangster/128/Born_To_Be_Gangster.mp3",
  ),
  Song(
    id: '9',
    title: "Warr",
    artist: "Juss",
    coverUrl: "https://cover.mr-jatt.im/thumb/514602/Waar-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202509/EVERLAST/128/Waar.mp3",
  ),
  Song(
    id: '10',
    title: "Tum Hi Ho",
    artist: "Arijit Singh",
    coverUrl: "https://pagalnew.com/coverimages/Tum-Hi-Ho-Aashiqui-2-500-500.jpg",
    audioUrl: "https://pagalnew.com/128-downloads/1234",
  ),

  Song(
    id: '11',
    title: "Tension",
    artist: "Diljit Dosanjh",
    coverUrl: "https://cover.mr-jatt.im/thumb/512167/Tension-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202502/Advisory/128/Tension.mp3",
  ),

  Song(
    id: '12',
    title: "Kaun Sunega",
    artist: "Kishore Kumar",
    coverUrl: "https://cover.mr-jatt.im/thumb/36267/Kaun-Sunega-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Sad_Songs/201705/Broken_Heart_Songs_CD_5/128/Kaun_Sunega.mp3",
  ),

  Song(
    id: '13',
    title: "Kaaliyan",
    artist: "Juss",
    coverUrl: "https://cover.mr-jatt.im/thumb/514602/Kaaliyan-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202509/EVERLAST/128/Kaaliyan.mp3",
  ),


  Song(
    id: '14',
    title: "Salok Mahaalla 9",
    artist: "bir Singh",
    coverUrl: "https://cover.mr-jatt.im/thumb/513061/Salok-Mahalla-9-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202505/Guru_Nanak_Jahaz/128/Salok_Mahalla_9.mp3",
  ),
  Song(
    id: '15',
    title: "Rich Heart",
    artist: "Gurinder Gill",
    coverUrl: "https://cover.mr-jatt.im/thumb/514578/Rich-Heart-1.jpg",
    audioUrl: "https://cdnsongs.com/music/data/Punjabi/202509/Rich_Heart/128/Rich_Heart.mp3",
  ),

];